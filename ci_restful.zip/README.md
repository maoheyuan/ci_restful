ci_admin[ 系统处理开发阶段，如有不足请多多包涵]
============

ci_admin 是一个完整的，简单的移动电商后台管理平台，可用于二次开发使用，所用到了以下开源框架 在此特别感谢


前端框架
-------
1.Detail_Admin<br>


后端框架
------
CodeIgniter




模块主要有以下功能模块
---------------------

1.登录模块<br>
2.首页统计模块<br>
3.管理员管理模块<br>
4.会员管理模块<br>
5.商品模块<br>
6.商品分类模块<br>
7.订单管理模块<br>
8.订单商品模块<br>
9.常用设置模块<br>
10.我的中心模块<br>


后台功能模块展示
--------
登录模块<br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/0.png"  /><br>
首页统计模块<br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/1.png"  /><br>
管理员管理模块<br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/6.png"  /><br>
会员管理模块<br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/4.png"  /><br>
订单管理模块<br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/5.png"  /><br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/5-1.png"  /><br>
商品分类模块<br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/2.png" /><br>
商品模块<br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/3.png" /><br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/3-1.png" /><br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/3-2.png" /><br>
日志管理模块<br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/7.png" /><br>
常用设置模块<br>
<img src="http://ov62dwm3x.bkt.clouddn.com/ciadmin/images/8.png" /><br>
在线交流
--------
若你在使用过程中有任何经验、想法、疑惑，都可以通过电子邮件869330407@qq.com来与我交流；


License
-------

ci_admin 遵循MIT License；
